from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Employee
from .models import Payslip
from django.views.decorators.csrf import csrf_protect

# Create your views here.
def home_page(request):
    employee_objects = Employee.objects.all()
    return render(request, 'payroll_app/Employee.html', {'employee':employee_objects})

def new_employee(request):
    employee_objects = Employee.objects.all()
    if(request.method=="POST"):
        name = request.POST.get('uname')
        id_number = request.POST.get('idnumber')
        rate = request.POST.get('rate')
        allowance_notfloat = request.POST.get('allowance')
        overtime_pay = 0
        try:
            allowance = float(allowance_notfloat)
        except ValueError:
            # if value of allowance cannot be converted to a float
            allowance = 0.0

        if Employee.objects.filter(id_number=id_number).exists():
            messages.error(request, 'Employee already exists')
            return render(request, 'payroll_app/create_employee.html')
        else:
            Employee.objects.create(name=name, id_number=id_number, rate=rate, allowance=allowance)
            # if wala pa then create an object for new employee
            messages.success(request, 'Employee created successfully')
            return render(request, 'payroll_app/create_employee.html')
        
    else:
        return render(request, 'payroll_app/create_employee.html')

def delete_employee(request, pk):
    # get pk of that row
    d = get_object_or_404(Employee,pk=pk)
    d.delete()
    messages.success(request, 'Employee deleted successfully')
    return redirect('home_page')

def update_employee(request, pk):
    if(request.method=="POST"):
        id_number = request.POST.get('idnumber')
        rate = request.POST.get('rate')
        allowance = request.POST.get('allowance')
        Employee.objects.filter(pk=pk).update(id_number=id_number, rate=rate, allowance=allowance, overtime_pay=overtime_pay)
        messages.success(request, 'Employee details updated successfully')
        return redirect('update_employee', pk=pk)
    else:
        d = get_object_or_404(Employee, pk=pk)
        return render(request, 'payroll_app/update_employee.html', {'d':d})

def payslips_page(request):
    employee_objects = Employee.objects.all()
    payslip_objects = Payslip.objects.all()
    return render(request, 'payroll_app/Payslips.html', {'employee':employee_objects, 'payslip':payslip_objects})

def create_payslip(request):
     employee_objects = Employee.objects.all()
     payslip_objects = Payslip.objects.all()
     if(request.method=="POST"):
         id_number = request.POST.get('selected_option_id')
         month = request.POST.get('selected_option_month')
         year = request.POST.get('year')
         pay_cycle = request.POST.get('selected_option_cycle')
         if int(pay_cycle) == 1:
            if id_number == "All Employees":
                for employee in employee_objects:
                    # get yung employee na yon na may id number na yon 
                    rate = employee.rate
                        # just call cyclerate later when calculating the tax sa front end 
                    date_range = "1-15"
                    pag_ibig = 100 
                    earnings_allowance = employee.getAllowance()
                    deductions_health = 0 
                    sss = 0 
                    overtime = employee.getOvertime()
                    deductions_tax = ((rate*0.5)+ earnings_allowance + overtime - pag_ibig)*0.2
                    total_pay = ((rate*0.5)+ earnings_allowance + overtime - pag_ibig) - deductions_tax
                    Payslip.objects.create(id_number=employee, month=month, date_range=date_range, year=year, pay_cycle=pay_cycle, rate=rate, earnings_allowance=earnings_allowance, deductions_tax=deductions_tax, deductions_health=deductions_health, pag_ibig=pag_ibig, sss=sss, overtime=overtime, total_pay = total_pay)
                    # blue is from the models.py, the white is the variable above
                    employee.resetOvertime() 
                messages.success(request, 'Payslip created successfully')
                return redirect('payslips_page')
                        # blue is from the models.py, the white is the variable above
                        # reset overtime method in models 

            else: 
                currentemployee = Employee.objects.get(id_number=id_number)
                # get object na may idnumber non 
                # get yung idnumber nung employee na yon
                if Payslip.objects.filter(id_number=currentemployee, month=month, year=year, pay_cycle=pay_cycle).exists():
                    # filter if may instance na nung employee na yon sa mga payslip 
                    # lahat need mag exist so that it won't pass through
                    messages.error(request, 'Payslip already exists')
                    return redirect('payslips_page')
                else:
                    employee = Employee.objects.get(id_number=id_number)
                        # get yung employee na yon na may id number na yon 
                    rate = employee.rate
                        # just call cyclerate later when calculating the tax sa front end 
                    date_range = "1-15"
                    pag_ibig = 100 
                    earnings_allowance = employee.getAllowance()
                    deductions_health = 0 
                    sss = 0 
                    overtime = employee.getOvertime()
                    deductions_tax = ((rate*0.5)+ earnings_allowance + overtime - pag_ibig)*0.2
                    total_pay = ((rate*0.5)+ earnings_allowance + overtime - pag_ibig) - deductions_tax
                    Payslip.objects.create(id_number=employee, month=month, date_range=date_range, year=year, pay_cycle=pay_cycle, rate=rate, earnings_allowance=earnings_allowance, deductions_tax=deductions_tax, deductions_health=deductions_health, pag_ibig=pag_ibig, sss=sss, overtime=overtime, total_pay = total_pay)
                    # blue is from the models.py, the white is the variable above
                    messages.success(request, 'Payslip created successfully')
                    employee.resetOvertime() 
                    return redirect('payslips_page')
                    # blue is from the models.py, the white is the variable above
                    # reset overtime method in models 
         else: 
            if id_number == "All Employees":
                for employee in employee_objects:
                    date_range = "16-30"
                        # get yung employee na yon na may id number na yon 
                    rate = employee.rate
                        # just call cyclerate later when calculating the tax sa front end 
                    earnings_allowance = employee.getAllowance()
                    deductions_health = 0.04* rate
                    sss = 0.045*rate
                    pag_ibig = 0
                    overtime = employee.getOvertime()
                    deductions_tax = ((rate*0.5)+ earnings_allowance + overtime - deductions_health - sss)*0.2
                    total_pay = ((rate*0.5)+ earnings_allowance + overtime - deductions_health - sss) - deductions_tax
                    Payslip.objects.create(id_number=employee, month=month, date_range=date_range, year=year, pay_cycle=pay_cycle, rate=rate, earnings_allowance=earnings_allowance, deductions_tax=deductions_tax, deductions_health=deductions_health, pag_ibig=pag_ibig, sss=sss, overtime=overtime, total_pay = total_pay)
                    employee.resetOvertime() 
                        # reset overtime method in models 
                messages.success(request, 'Payslip created successfully')
                return redirect('payslips_page')
            else: 
                currentemployee = Employee.objects.get(id_number=id_number)
                if Payslip.objects.filter(id_number=currentemployee, month=month, year=year, pay_cycle=pay_cycle).exists():
                    messages.error(request, 'Payslip already exists')
                    return redirect('payslips_page')
                else: 
                    date_range = "16-30"
                    employee = Employee.objects.get(id_number=id_number)
                        # get yung employee na yon na may id number na yon 
                    rate = employee.rate
                        # just call cyclerate later when calculating the tax sa front end 
                    earnings_allowance = employee.getAllowance()
                    deductions_health = 0.04* rate
                    sss = 0.045*rate
                    pag_ibig = 0
                    overtime = employee.getOvertime()
                    deductions_tax = ((rate*0.5)+ earnings_allowance + overtime - deductions_health - sss)*0.2
                    total_pay = ((rate*0.5)+ earnings_allowance + overtime - deductions_health - sss) - deductions_tax
                    Payslip.objects.create(id_number=employee, month=month, date_range=date_range, year=year, pay_cycle=pay_cycle, rate=rate, earnings_allowance=earnings_allowance, deductions_tax=deductions_tax, deductions_health=deductions_health, pag_ibig=pag_ibig, sss=sss, overtime=overtime, total_pay = total_pay)
                    employee.resetOvertime() 
                        # reset overtime method in models 
                    messages.success(request, 'Payslip created successfully')
                    return redirect('payslips_page')
     else:
         return render(request, 'payroll_app/Payslips.html', {'employee':employee_objects, 'payslip':payslip_objects})
# If cycle 1  Calls Reset overtime method  If cycle 2 Just put 0 to pag-ibig Calls Reset overtime method 

def overtime_pay(request, pk):
    if (request.method == "POST"):
        d = get_object_or_404(Employee,pk=pk)
        overtime_x = request.POST.get('overtime')
        overtime_pay = (float(Employee.objects.get(pk=pk).rate)/160) * 1.5 * float(overtime_x)
        Employee.objects.filter(pk=pk).update(overtime_pay=overtime_pay)
        return redirect('home_page')
    
def view_payslip(request, pk):
    pay = get_object_or_404(Payslip, pk=pk)
    cycle = pay.getPay_cycle()
    if int(cycle) == 1:
        return render(request, 'payroll_app/view_payslip_1.html', {'pay':pay})
    else:
        return render(request, 'payroll_app/view_payslip_2.html', {'pay':pay})
    
    

