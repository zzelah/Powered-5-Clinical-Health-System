from django.db import models
from datetime import datetime
from django.core.validators import MinValueValidator


class Appointment(models.Model):
    appointment_id = models.CharField(max_length=60, primary_key=True, unique=True)
    patient_name = models.CharField(max_length=50)
    contact_person_name = models.CharField(max_length=50)
    phone_number = models.BigIntegerField()
    start_date_and_time = models.CharField(max_length=50, null=True)
    end_date_and_time = models.CharField(max_length=50, null=True)
    therapist_schedule = models.ForeignKey('Schedule', null=True, on_delete=models.CASCADE)

    def save(self, *args, **kwargs):
        # Automatically generate appointment_id based on PatientName and timestamp
        if not self.appointment_id:
            timestamp_str = self.start_date_and_time.strftime('%Y-%m-%d %H:%M:%S')
            self.appointment_id = f"{self.patient_name}_{timestamp_str}"

        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.appointment_id} - {self.patient_name}"


class Therapist(models.Model):
    pt_license_no = models.IntegerField(primary_key=True, unique=True)
    pt_name = models.CharField(max_length=255)

    def __str__(self):
        return f"PT License No.: {self.pt_license_no} - PT Name: {self.pt_name}"


class Schedule(models.Model):
    schedule_id = models.AutoField(primary_key=True)
    color = models.CharField(max_length=50, null=True)
    day_of_week = models.IntegerField(null=True)
    start_time = models.TimeField(null=True)
    end_time = models.TimeField(null=True)
    pt_license = models.ForeignKey('Therapist', on_delete=models.CASCADE)

    def __str__(self):
        return f'Schedule ID: {self.schedule_id}, Day: {self.day_of_week}, Start Time: {self.start_time}, End Time: {self.end_time}, Therapist License: {self.pt_license}'

    


class Patient(models.Model):
    patient_id = models.PositiveIntegerField(primary_key=True, unique=True, verbose_name="Patient ID", help_text="Format: 9999999")
    first_name = models.CharField(max_length=30, verbose_name="First Name", help_text="Format: XXXXXXXXXXX")
    middle_name = models.CharField(max_length=30, blank=True, null=True, verbose_name="Middle Name", help_text="Format: XXXXXXXXXXX")
    last_name = models.CharField(max_length=30, verbose_name="Last Name", help_text="Format: XXXXXXXXXXX")
    birth_month = models.PositiveSmallIntegerField(verbose_name="Birth Month", help_text="An integer from 1-12")
    birth_day = models.PositiveSmallIntegerField(verbose_name="Day of Birth", help_text="An integer from 1-31")
    birth_year = models.PositiveSmallIntegerField(verbose_name="Birth Year", help_text="Format: 9999")
    age = models.PositiveSmallIntegerField(verbose_name="Age", help_text="Any integer > 0")
    sex = models.CharField(max_length=6, verbose_name="Sex", help_text="Format: XXXXXX")
    mobile_number = models.CharField(max_length=11,verbose_name="Mobile Number", help_text="Format: 99999999999")
    email = models.EmailField(max_length=30, blank=True, null=True, verbose_name="Email", help_text="Format: XXXXXXXXXXX")
    house_and_street = models.CharField(max_length=50, blank=True, null=True, verbose_name="House No. and Street", help_text="Format: XXXXXXXXXXX")
    village_or_barangay = models.CharField(max_length=50, blank=True, null=True, verbose_name="Village/Barangay", help_text="Format: XXXXXXXXXXX")
    city_or_municipality = models.CharField(max_length=30, blank=True, null=True, verbose_name="City/Municipality", help_text="Format: XXXXXXXXXXX")
    province = models.CharField(max_length=30, blank=True, null=True, verbose_name="Province", help_text="Format: XXXXXXXXXXX")

    def __str__(self):
        return f"{self.first_name} {self.last_name} (ID: {self.patient_id})"

    

class ChiefMedicalConcern(models.Model):
    chief_concern_id = models.PositiveIntegerField(primary_key=True, unique=True, verbose_name="Chief Concern ID", help_text="Format: 9999999")
    title = models.CharField(max_length=150, verbose_name="Title", help_text="Format: XXXXXXXXXXX")
    # intake_form_file = models.FileField(upload_to="intake_forms/", verbose_name="Intake Form File", help_text="Format: path/to/file/Name_of_File.pdf")
    intake_form_file = models.CharField(max_length=150, verbose_name="Title", help_text="Format: XXXXXXXXXXX")
    sf36_file = models.FileField(upload_to="sf36_forms/", blank=True, null=True, verbose_name="SF36 File", help_text="Format: path/to/file/Name_of_File.pdf")
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, verbose_name="Patient ID", default = 0)

    def __str__(self):
        return f"{self.title} (ID: {self.chief_concern_id})"
    
class SF36(models.Model):
    sf36_id = models.AutoField(primary_key=True)
    q1 = models.SmallIntegerField()
    q2 = models.SmallIntegerField()
    q3 = models.SmallIntegerField()
    q4 = models.SmallIntegerField()
    q5 = models.SmallIntegerField()
    q6 = models.SmallIntegerField()
    q7 = models.SmallIntegerField()
    q8 = models.SmallIntegerField()
    q9 = models.SmallIntegerField()
    q10 = models.SmallIntegerField()
    q11 = models.SmallIntegerField()
    q12 = models.SmallIntegerField()
    q13 = models.SmallIntegerField()
    q14 = models.SmallIntegerField()
    q15 = models.SmallIntegerField()
    q16 = models.SmallIntegerField()
    q17 = models.SmallIntegerField()
    q18 = models.SmallIntegerField()
    q19 = models.SmallIntegerField()
    q20 = models.SmallIntegerField()
    q21 = models.SmallIntegerField()
    q22 = models.SmallIntegerField()
    q23 = models.SmallIntegerField()
    q24 = models.SmallIntegerField()
    q25 = models.SmallIntegerField()
    q26 = models.SmallIntegerField()
    q27 = models.SmallIntegerField()
    q28 = models.SmallIntegerField()
    q29 = models.SmallIntegerField()
    q30 = models.SmallIntegerField()
    q31 = models.SmallIntegerField()
    q32 = models.SmallIntegerField()
    q33 = models.SmallIntegerField()
    q34 = models.SmallIntegerField()
    q35 = models.SmallIntegerField()
    q36 = models.SmallIntegerField()
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)

    def getPhysicalFunctioning(self):
        return self.q3 + self.q4 + self.q5 + self.q6 + self.q7 + self.q8 + self.q9 + self.q10 + self.q11 + self.q12
    
    def getRoleLimitationsPhysical(self):
        return self.q13 + self.q14 + self.q15 + self.q16

    def getRoleLimitationsEmotional(self):
        return self.q17 + self.q18 + self.q19
    
    def getEnergyFatigue(self):
        return self.q23 + self.q27 + self.q29 + self.q31
    
    def getEmotionalWellbeing(self):
        return self.q24 + self.q25 + self.q26 + self.q28 + self.q30
    
    def getSocialFunctioning(self):
        return self.q20 + self.q32
    
    def getPain(self):
        return self.q21 + self.q22
    
    def getGeneralHealth(self):
        return self.q1 + self.q33 + self.q34 + self.q35 + self.q36


class Attachment(models.Model):
    attachment_id = models.BigAutoField(primary_key=True)
    attachment_file = models.FileField(upload_to='attachments/')
    chief_concern = models.ForeignKey(ChiefMedicalConcern, on_delete=models.CASCADE)

    def __str__(self):
        return str(self.attachment_file)


class Session(models.Model):
    session_id = models.PositiveIntegerField(primary_key=True, unique=True, verbose_name="Session ID", help_text="Format: 9999999", validators=[MinValueValidator(1)])

    month = models.PositiveSmallIntegerField(default=datetime.now().month, verbose_name="Month", help_text="An integer from 1-12")

    day = models.PositiveSmallIntegerField(default=datetime.now().day, verbose_name="Day", help_text="An integer from 1-31")

    year = models.PositiveSmallIntegerField(default=datetime.now().year, verbose_name="Year", help_text="A 4-digit integer > 0")

    session_notes = models.CharField(max_length=256, default="", verbose_name="Session Notes", help_text="Format: path/to/file/Name_of_File.pdf")

    subtotal = models.DecimalField(max_digits=9, decimal_places=2, default=0.00, verbose_name="Subtotal", help_text="Format: 9999999.99")

    discount_type = models.CharField(max_length=20, blank=True, null=True, verbose_name="Discount Type", help_text="Format: XXXXXXXXXXX")

    discount_amount = models.DecimalField(max_digits=9, decimal_places=2, default=0.00, blank=True, null=True, verbose_name="Discount Amount", help_text="Format: 9999999.99")

    total_amount = models.DecimalField(max_digits=9, decimal_places=2, default=0.00, verbose_name="Total Amount", help_text="Format: 9999999.99")

    mode_of_payment = models.CharField(max_length=20, default="Cash", verbose_name="Mode of Payment", help_text="Format: XXXXXXXXXXX")

    reference_number = models.PositiveBigIntegerField(blank=True, null=True, verbose_name="Reference Number", help_text="Format: 99999999999999999999")

    pt_license_number = models.PositiveIntegerField(verbose_name="PT License Number", help_text="Format: 9999999")

    patient_id = models.PositiveIntegerField(verbose_name="Patient ID", help_text="Format: 9999999")

    def __str__(self):
        return f"Session ID: {self.session_id}, Date: {self.year}-{self.month}-{self.day}, PT License: {self.pt_license_number}, Patient ID: {self.patient_id}"


class Service(models.Model):
    service_id = models.CharField(max_length=100, primary_key=True, unique=True, verbose_name="Service ID", help_text="Format: XXXXXXXXXXX")

    base_price = models.DecimalField(max_digits=9, decimal_places=2, default=0.00, verbose_name="Base Price", help_text="Format: 9999999.99")

    # Field: Package (Unary Relationship)
    package = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, verbose_name="Package", help_text="Service ID of the package to which this service belongs")

    def __str__(self):
        return f"Service ID: {self.service_id}, Base Price: {self.base_price}, Package: {self.package}"


class Session_Service(models.Model):
    session_id = models.ForeignKey(Session, on_delete=models.CASCADE, verbose_name="Session ID", help_text="Format: 9999999")

    service_id = models.ForeignKey(Service, on_delete=models.CASCADE, verbose_name="Service ID", help_text="Format: XXXXXXXXXXX")

    declared_price = models.DecimalField(max_digits=9, decimal_places=2, default=0.00, verbose_name="Declared Price", help_text="Format: 9999999.99")

    quantity = models.PositiveSmallIntegerField(default=1, verbose_name="Quantity", help_text="An integer from 1-255")

    class Meta:
        # Use UniqueConstraint to define a composite primary key
        constraints = [
            models.UniqueConstraint(fields=['session_id', 'service_id'], name='unique_session_service')
        ]

    def __str__(self):
        return f"Session ID: {self.session_id}, Service ID: {self.service_id}, Declared Price: {self.declared_price}, Quantity: {self.quantity}"