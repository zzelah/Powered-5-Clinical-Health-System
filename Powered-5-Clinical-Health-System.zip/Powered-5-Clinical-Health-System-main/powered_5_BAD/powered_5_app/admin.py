from django.contrib import admin
from .models import Appointment, Schedule, Therapist, Patient, ChiefMedicalConcern, Attachment, Session, Service, Session_Service, SF36


# Register your models here.

admin.site.register(Appointment)
admin.site.register(Therapist)
admin.site.register(Schedule)
admin.site.register(Patient)
admin.site.register(ChiefMedicalConcern)
admin.site.register(SF36)
admin.site.register(Attachment)
admin.site.register(Session)
admin.site.register(Service)
admin.site.register(Session_Service)



