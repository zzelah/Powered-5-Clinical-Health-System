
# # # powered_5_app/forms.py
# from django import forms
# from .models import ChiefMedicalConcern

# # class ChiefMedicalConcernForm(forms.ModelForm):
# #     title = forms.CharField(max_length=150, label='Title')
# #     year = forms.CharField(max_length=4, label='Year')
# #     chief_complaint = forms.CharField(max_length=255, label='Chief Complaint')
# #     short_term_goal = forms.CharField(max_length=255, label='Short Term Goal')
# #     long_term_goal = forms.CharField(max_length=255, label='Long Term Goal')
# #     patient_id = forms.CharField(max_length=7, label='Patient ID')
    

# #     class Meta:
# #         model = ChiefMedicalConcern
# #         fields = ['title', 'year', 'chief_complaint', 'short_term_goal', 'long_term_goal', 'functionalfindings', 'prognosis']
