import random, json
from django.conf import settings
from django.urls import reverse
from django.http import HttpResponse, JsonResponse
from django.core import serializers
from django.core.serializers import serialize, deserialize
from datetime import date
from datetime import datetime, timedelta
from django.utils import timezone
from django.shortcuts import render, redirect, get_object_or_404
#from .forms import TherapistScheduleForm
from django.contrib import messages
from django.contrib.staticfiles import finders
from .models import Appointment, Schedule, Therapist, Patient, ChiefMedicalConcern, Attachment, Session, Service, Session_Service, SF36

from PIL import Image
import matplotlib.pyplot as plt
import os
import uuid
from django.template import loader
from django.template import RequestContext
import base64
import io
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from django.template.loader import render_to_string
from io import BytesIO
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import Image as PlatypusImage

# from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from matplotlib.backends.backend_agg import FigureCanvasAgg


def generate_random_id():
    return str(random.randint(0, 9999999)).zfill(7)

# Create your views here.
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if username == 'powered_recovery_PT' and password == 'coachpaul':
            return redirect('home')
        else:
            messages.error(request, 'Invalid login credentials.')
            return render(request, 'powered_5_app/login.html')  # Return the login page with error message

    return render(request, 'powered_5_app/login.html')


def user_logout(request):
    return redirect('login')

def home(request):
    if request.method == 'POST' and 'calendar_button' in request.POST:
        return redirect('calendar')
    return render(request, 'powered_5_app/home.html')

def calendar(request):
    all_appointments = Appointment.objects.all()
    all_therapist_schedules = Schedule.objects.all()
    return render (request, 'powered_5_app/calendar.html', {'appointments':all_appointments, 'pt_schedules':all_therapist_schedules })

def all_appointments(request):
    all_appointments = Appointment.objects.filter(start_date_and_time__gte=timezone.now())
    serialized_appointments = serialize('json', all_appointments)
    appointments_data = list(deserialize('json', serialized_appointments))

    # Prepare the data in the required format for FullCalendar
    events = []
    for appointment_data in appointments_data:
        fields = appointment_data.object
        event = {
            'title': fields.patient_name,
            'start': fields.start_date_and_time,
            'end': fields.end_date_and_time,
            'id': fields.pk,  # Access 'pk' within the 'object' attribute
        }
        events.append(event)

    return JsonResponse(events, safe=False)

def all_therapist_schedules(request):
    all_therapist_schedules = Schedule.objects.all()
    serialized_schedules = serialize('json', all_therapist_schedules)
    schedules_data = list(deserialize('json', serialized_schedules))

    # Prepare the data in the required format for FullCalendar
    events = []
    for schedule_data in schedules_data:
        fields = schedule_data.object
        therapist_name = fields.pt_license.pt_name
        color = fields.color
        start_time = fields.start_time
        end_time = fields.end_time
        day_of_week = fields.day_of_week

        # Get the current date
        current_date = datetime.now().date()

        # Find the next occurrence of the specified day_of_week
        delta_days = (day_of_week - current_date.weekday() + 7) % 7
        next_occurrence = current_date + timedelta(days=delta_days)

        # Create the event for each occurrence
        while next_occurrence.year == current_date.year:
            start_datetime = datetime.combine(next_occurrence, start_time)
            end_datetime = datetime.combine(next_occurrence, end_time)

            event = {
                'title': "PT: "+ therapist_name,
                'start': start_datetime.isoformat(),
                'end': end_datetime.isoformat(),
                'color': color,
                'id': fields.pk,  # Access 'pk' within the 'object' attribute
            }
            events.append(event)

            # Move to the next week
            next_occurrence += timedelta(weeks=1)

    return JsonResponse(events, safe=False)

def add_appointment(request):
    try:
        # Parse data from the request
        patient_name = request.POST.get('patientName')
        contact_name = request.POST.get('contactName')
        phone_number = request.POST.get('phoneNumber')
        selected_datetime_str = request.POST.get('selectedDate')
        start_time_str = request.POST.get('startTime')
        end_time_str = request.POST.get('endTime')
        therapist_schedule_id = request.POST.get('therapistScheduleId')

        # Remove 'Z' from the datetime string (assuming it represents UTC)
        selected_datetime_str = selected_datetime_str.replace('Z', '')

        # Parse ISO 8601 formatted datetime string
        selected_datetime = datetime.fromisoformat(selected_datetime_str)

        # Format the date without timezone information
        selected_date_str = selected_datetime.strftime('%Y-%m-%d')

        # Combine date and time parts to form complete datetime strings
        start_date_time_str = f"{selected_date_str} {start_time_str}"
        end_date_time_str = f"{selected_date_str} {end_time_str}"

        # Parse datetime strings
        format_str = '%Y-%m-%d %H:%M'
        start_date_time = datetime.strptime(start_date_time_str, format_str)
        end_date_time = datetime.strptime(end_date_time_str, format_str)

        # Retrieve the Schedule instance corresponding to the therapist_schedule_id
        therapist_schedule = Schedule.objects.get(pk=therapist_schedule_id)

        # Create and save the Appointment object
        appointment = Appointment(
            patient_name=patient_name,
            contact_person_name=contact_name,
            phone_number=phone_number,
            start_date_and_time=start_date_time,
            end_date_and_time=end_date_time,
            therapist_schedule=therapist_schedule
        )
        appointment.save()

        return JsonResponse({'status': 'success'})

    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})
    
def edit_appointment(request, pk):
    # Retrieve the appointment based on the provided ID
    edit_appointment = get_object_or_404(Appointment, pk=pk)
    
    if request.method == 'POST':
        patient_name = request.POST.get('editPatientName')
        contact_name = request.POST.get('editContactName')
        phone_number = request.POST.get('editPhoneNumber')
        selected_datetime_str = request.POST.get('selectedDate')
        start_time_str = request.POST.get('editStartTime')
        end_time_str = request.POST.get('editEndTime')
        therapist_schedule_id = request.POST.get('therapistScheduleId')

        # Validate patient_name
        if not patient_name:
            return JsonResponse({'status': 'error', 'message': 'Patient name is required'})


        # Set default values for start_date_time and end_date_time
        start_date_time = None
        end_date_time = None

        # Remove 'Z' from the datetime string (assuming it represents UTC)
        selected_datetime_str = selected_datetime_str.replace('Z', '')

        # Parse ISO 8601 formatted datetime string
        selected_datetime = datetime.fromisoformat(selected_datetime_str)

        # Format the date without timezone information
        selected_date_str = selected_datetime.strftime('%Y-%m-%d')

        # Combine date and time parts to form complete datetime strings
        if start_time_str and end_time_str:
            start_date_time_str = f"{selected_date_str} {start_time_str}"
            end_date_time_str = f"{selected_date_str} {end_time_str}"

            # Parse datetime strings
            format_str = '%Y-%m-%d %H:%M'
            start_date_time = datetime.strptime(start_date_time_str, format_str)
            end_date_time = datetime.strptime(end_date_time_str, format_str)
        else:
            # Handle the case where either start or end time is not provided
            # You can raise an error, set default values, or handle it as appropriate for your application
            print("Error: Start or end time is missing")

        edit_appointment.patient_name = patient_name
        edit_appointment.contact_person_name = contact_name
        edit_appointment.phone_number = phone_number
        edit_appointment.start_date_and_time = start_date_time
        edit_appointment.end_date_and_time = end_date_time

        edit_appointment.save()

        return JsonResponse({'status': 'success'})
    elif request.method == 'GET':
        # If it's a GET request, return the appointment details in JSON format
        appointment_data = {
            'patientName': edit_appointment.patient_name,
            'contactName': edit_appointment.contact_person_name,
            'phoneNumber': edit_appointment.phone_number,
            'startTime': edit_appointment.start_date_and_time,
            'endTime': edit_appointment.end_date_and_time,
            'selectedDate': edit_appointment.start_date_and_time.split(' ')[0] if edit_appointment.start_date_and_time else ''
        }
        return JsonResponse(appointment_data)
    else:
        # For other request methods, return an error response
        return JsonResponse({'status': 'error', 'message': 'Unsupported request method'})
    
def delete_appointment(request, pk):
    appointment = get_object_or_404(Appointment, pk=pk)
    appointment.delete()
    return JsonResponse({'status': 'success'})

def add_therapist_schedule(request):
    if request.method == 'POST':
        therapist_name = request.POST.get('therapistName')
        pt_license = request.POST.get('ptLicense')
        color = request.POST.get('ptColor')
        events_json = request.POST.get('events')

        therapist, created = Therapist.objects.get_or_create(pt_license_no=pt_license, defaults={'pt_name': therapist_name})

        # Parse JSON data for events
        events = json.loads(events_json)

        # Save events for the therapist
        for event in events:
            start_time_str = event.get('start').strip()  # Remove leading/trailing spaces
            end_time_str = event.get('end').strip()      # Remove leading/trailing spaces
            

            # Parse start time and end time
            start_time = datetime.strptime(start_time_str, '%Y-%m-%d %H:%M').time()
            end_time = datetime.strptime(end_time_str, '%Y-%m-%d %H:%M').time()
            # Additional processing for weekday, if needed
            weekday = datetime.strptime(event.get('start'), '%Y-%m-%d %H:%M').weekday()

            Schedule.objects.create(
                pt_license=therapist,
                color = color,
                day_of_week=weekday,
                start_time=start_time,
                end_time=end_time
            )

        return JsonResponse({'status': 'success'})
    else:
        return JsonResponse({'status': 'error'})
    
def view_therapist_schedules(request):
    all_therapists = Therapist.objects.all()
    return render(request, 'powered_5_app/view_therapist_schedules.html', {'therapists':all_therapists})

def edit_therapist_schedule(request, pk):
    therapist = get_object_or_404(Therapist, pk=pk)
    therapist_schedules = Schedule.objects.filter(pt_license=pk)
    serialized_schedules = serialize('json', therapist_schedules)
    schedules_data = list(deserialize('json', serialized_schedules))

    if request.method == 'POST':
        therapist_name = request.POST.get('therapist')
        pt_license = request.POST.get('ptlicense')
        color = request.POST.get('ptcolor')
        events_json = request.POST.get('events')

        # Update therapist details
        therapist.pt_name = therapist_name
        therapist.pt_license_no = pt_license
        therapist.save()

        # Clear existing schedules for the therapist
        Schedule.objects.filter(pt_license=therapist).delete()

        # Parse JSON data for events
        events = json.loads(events_json)

        # Save events for the therapist
        for event in events:
            start_time_str = event.get('start').strip()  # Remove leading/trailing spaces
            end_time_str = event.get('end').strip()      # Remove leading/trailing spaces
            
            # Parse start time and end time
            start_time = datetime.strptime(start_time_str, '%Y-%m-%dT%H:%M:%S').time()
            end_time = datetime.strptime(end_time_str, '%Y-%m-%dT%H:%M:%S').time()
            # Additional processing for weekday, if needed
            weekday = datetime.strptime(event.get('start'), '%Y-%m-%dT%H:%M:%S').weekday()

            Schedule.objects.create(
                pt_license=therapist,
                color=color,
                day_of_week=weekday,
                start_time=start_time,
                end_time=end_time
            )

        return JsonResponse({'status': 'success'})
    else:
        # Prepare the data in the required format for FullCalendar
        events = []

        # Get the current date
        current_date = datetime.now().date()

        # Calculate the start date of the current week (Monday)
        start_of_week = current_date - timedelta(days=current_date.weekday())

        # Calculate the end date of the current week (Sunday)
        end_of_week = start_of_week + timedelta(days=6)

        # Initialize color outside the loop
        color = None

        for schedule_data in schedules_data:
            fields = schedule_data.object
            therapist_name = therapist.pt_name  # Access therapist name directly
            current_color = fields.color
            # If color is not initialized or current_color is different, update color
            if color is None or current_color != color:
                color = current_color

            start_time = fields.start_time
            end_time = fields.end_time
            day_of_week = fields.day_of_week


            start_time = fields.start_time
            end_time = fields.end_time
            day_of_week = fields.day_of_week

            # Adjust the day of the week if necessary to fit within the current week
            schedule_day = start_of_week + timedelta(days=(day_of_week - start_of_week.weekday()) % 7)

            # Combine the schedule_day with start_time and end_time
            start_datetime = datetime.combine(schedule_day, start_time)
            end_datetime = datetime.combine(schedule_day, end_time)

            event = {
                'title': therapist_name,
                'start': start_datetime.isoformat(),
                'end': end_datetime.isoformat(),
                'color': color,
                'id': fields.pk,  # Access 'pk' within the 'object' attribute
            }
            events.append(event)

        return JsonResponse({
            'therapist_name': therapist.pt_name,
            'pt_license_no': therapist.pt_license_no,
            'color': color,  # Assuming the color is constant for all events
            'events': events,
        })


def delete_therapist_and_schedules(request, pk):
    therapist = get_object_or_404(Therapist, pk=pk)
    therapist.delete()
    return JsonResponse({'status': 'success'})



def patientProfiles(request):
    patientProfileObjects = Patient.objects.all()
    return render(request, 'powered_5_app/profiles.html', {'patients':patientProfileObjects })

def addProfile(request):
    if request.method == "POST":
        # Get data from the form
        first_name = request.POST.get('first_name')
        middle_name = request.POST.get('middle_name')
        last_name = request.POST.get('last_name')
        birthdate_str = request.POST.get('birthdate')  # Retrieve birthdate as a string
        sex = request.POST.get('sex')
        mobile_number = request.POST.get('mobile_number')
        email = request.POST.get('email')
        house_and_street = request.POST.get('house_and_street')
        village_or_barangay = request.POST.get('village_or_barangay')
        city_or_municipality = request.POST.get('city_or_municipality')
        province = request.POST.get('province')

        # Generate a random 7-digit ID for Patient
        patient_id = generate_random_id()

        # Validate required fields
        if not first_name or not last_name or not birthdate_str or not sex or not mobile_number:
            messages.error(request, 'Please fill in all required fields')
            return redirect('add_patient')

        # Validate birthdate format
        try:
            birthdate = datetime.strptime(birthdate_str, '%m/%d/%Y').date()
        except ValueError:
            messages.error(request, 'Invalid birthdate format. Please use mm/dd/yyyy.')
            return redirect('add_patient')

        # Calculate age based on the provided birth date
        today = date.today()
        age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))

        # Create Patient instance and save to the database
        patient = Patient(
            patient_id=patient_id,
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            birth_month=birthdate.month,
            birth_day=birthdate.day,
            birth_year=birthdate.year,
            age=age,
            sex=sex,
            mobile_number=mobile_number,
            email=email,
            house_and_street=house_and_street,
            village_or_barangay=village_or_barangay,
            city_or_municipality=city_or_municipality,
            province=province
        )

        patient.save()

        messages.success(request, 'Patient created successfully')
        return redirect('patient_profiles')

    return render(request, 'powered_5_app/add_profile.html')

def viewProfile(request, pk):
    profile_pk = get_object_or_404(Patient, pk=pk)
    # chief_medical_concern = get_object_or_404(ChiefMedicalConcern, patient_id=pk)
    chief_medical_concerns = ChiefMedicalConcern.objects.filter(patient_id=pk)
    # intake_form_file = chief_medical_concern.intake_form_file
    try:
        sf36 = SF36.objects.get(patient=profile_pk)
    except:
        sf36 = ''
    return render(request, 'powered_5_app/view_patient_profile.html', {'p': profile_pk, 'chief_medical_concerns': chief_medical_concerns, 'sf36': sf36})

def updateProfile(request, pk):
    if request.method == "POST":
        # Get data from the form
        first_name = request.POST.get('first_name')
        middle_name = request.POST.get('middle_name')
        last_name = request.POST.get('last_name')
        birthdate_str = request.POST.get('birthdate')  # Adjusted to match the new datepicker ID
        sex = request.POST.get('sex')
        mobile_number = request.POST.get('mobile_number')
        email = request.POST.get('email')
        house_and_street = request.POST.get('house_and_street')
        village_or_barangay = request.POST.get('village_or_barangay')
        city_or_municipality = request.POST.get('city_or_municipality')
        province = request.POST.get('province')

        # Validate required fields
        if not first_name or not last_name or not birthdate_str or not sex or not mobile_number:
            messages.error(request, 'Please fill in all required fields')
            return redirect('update_patient', pk=pk)

        # Validate birthdate format
        try:
            birthdate = datetime.strptime(birthdate_str, '%m/%d/%Y').date()
        except ValueError:
            messages.error(request, 'Invalid birthdate format. Please use mm/dd/yyyy.')
            return redirect('update_patient', pk=pk)

        # Calculate age based on the provided birth date
        today = date.today()
        age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))

        # Update Patient instance in the database
        Patient.objects.filter(pk=pk).update(
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            birth_month=birthdate.month,
            birth_day=birthdate.day,
            birth_year=birthdate.year,
            age=age,
            sex=sex,
            mobile_number=mobile_number,
            email=email,
            house_and_street=house_and_street,
            village_or_barangay=village_or_barangay,
            city_or_municipality=city_or_municipality,
            province=province
        )

        messages.success(request, 'Patient updated successfully')
        return redirect('view_patient', pk=pk)

    else:
        profile_pk = get_object_or_404(Patient, pk=pk)
        return render(request, 'powered_5_app/update_profile.html', {'p': profile_pk})


def deleteProfile(request, pk):
    Patient.objects.filter(pk=pk).delete()
    return redirect('patient_profiles')

def display_image(request,pk):
    profile_pk = get_object_or_404(Patient, pk=pk)

    def on_image_click(event):
        x = int(event.xdata)
        y = int(event.ydata)
        print(f"Clicked at coordinates: ({x}, {y})")
        draw_circle(x, y, radius=20, color='orange')

    def draw_circle(x, y, radius, color):
        circle = plt.Circle((x, y), radius, color=color, fill=False)
        ax.add_patch(circle)
        plt.draw()

    # Load the image
    img_path = os.path.join("powered_5_app/static/img", "Pain_Chart.png")
    img = Image.open(img_path)

    # Display the image using matplotlib
    fig, ax = plt.subplots()
    ax.imshow(img)
    ax.axis('off')  # Hide axes

    # Bind the click event
    fig.canvas.mpl_connect('button_press_event', on_image_click)
            

    plt.show()
    modified_image_bytesio = io.BytesIO()
    fig.savefig(modified_image_bytesio, format='png')
    modified_image_bytesio.seek(0)  # Move the cursor to the start of the BytesIO object

    encoded_image = base64.b64encode(modified_image_bytesio.getvalue()).decode("utf-8")
    
    if encoded_image is not None:
    # Your code to use encoded_image here
        print("encoded_image exists:", encoded_image)
    else:
        print("encoded_image does not exist or is None")
#   Save the modified image
    unique_filename = str(uuid.uuid4()) + "_Modified_Pain_Chart.png"
    save_path = os.path.join("powered_5_app/static/img/Pain_Chart", unique_filename)

#   Save the modified image
    fig.savefig(save_path)

    # # return encoded_image
    # return render(request, 'powered_5_app/clickable_image.html',{'encoded_image': encoded_image})
    return render(request, 'powered_5_app/create-intake-form-final.html', {'p': profile_pk, 'encoded_image': encoded_image})
    # return redirect('createintakeform', pk=pk)

def createintakeform(request,pk):
    profile_pk = get_object_or_404(Patient, pk=pk)
    if request.method == "POST":
        # Get data from the form
        title = request.POST.get('title')
        year = request.POST.get('year')
        chiefcomplaint = request.POST.get('chiefcomplaint')
        shortterm = request.POST.get('shortterm')
        longterm = request.POST.get('longterm')
        functionalfindings = request.POST.get('functionalfindings')
        prognosis = request.POST.get('prognosis')
        #for pain chart image
        encoded_image = request.POST.get('encoded_image')
        decoded_image = base64.b64decode(encoded_image)
        image_bytesio = BytesIO(decoded_image)

        #sf36_file = it can be null muna
        #updateinstance of intakeform
        # Image
        # relative_path = "powered_5_app/static/img/Powered_Recovery_Logo.png"
        image_path = "powered_5_app/static/img/Powered_Recovery_Logo.png"
        # relative_path = "powered_5_app/static/img/Powered_Recovery_Logo.png"
        # image_path = finders.find(relative_path)

        # Generate a random 7-digit ID for Patient
        chief_concern_id = generate_random_id()

        #Generate temporary for intake_form_file 
        intake_form_file = request.POST.get('year')

        # Get FK of Patient 
        patient = Patient.objects.get(pk=pk)
        
        # patient = patient.pk
        image = PlatypusImage(image_path)
        # Generate PDF
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        elements = []

        # Define style for the paragraphs
        style = ParagraphStyle(name='Normal', fontSize=12, leading=30)
        predefined_styles = getSampleStyleSheet()
        title_style = ParagraphStyle(name='CustomStyle', fontSize=20, leading=14, textColor=colors.black, alignment=1)
        pain_chart_style = ParagraphStyle(name='PainChartStyle', fontSize=16, leading=14, textColor=colors.black, alignment=1)
        label_text_style = predefined_styles['Heading4']
        body_text_style = predefined_styles['BodyText']

        # Add content to PDF
        base64_image = PlatypusImage(image_bytesio, width=4*inch, height=3*inch)
        elements.append(image)
        elements.append(Paragraph("INTAKE FORM", title_style))
        elements.append(Spacer(1, 12))
        elements.append(Paragraph(f"TITLE OF SESSION: {title}", label_text_style))
        elements.append(Paragraph(f"DATE OF SESSION: {year}", label_text_style))
        elements.append(Paragraph(f"CHIEF COMPLAINT: ", label_text_style))
        elements.append(Paragraph(f" {chiefcomplaint}", body_text_style ))
        elements.append(Spacer(1, 12))
        elements.append(Paragraph(f"PAIN CHART", pain_chart_style))
        elements.append(Spacer(1, 12))
        elements.append(base64_image)
        elements.append(Spacer(1, 12))
        elements.append(Paragraph(f"SHORT TERM GOALS: ", label_text_style))
        elements.append(Paragraph(f"{shortterm}", body_text_style))
        elements.append(Paragraph(f"LONG TERM GOALS:", label_text_style))
        elements.append(Paragraph(f" {longterm}", body_text_style))
        elements.append(Paragraph(f"FUNCTIONAL FINDINGS: ", label_text_style))
        elements.append(Paragraph(f"{functionalfindings}", body_text_style))
        elements.append(Paragraph(f"PROGNOSIS: ", label_text_style))
        elements.append(Paragraph(f"{prognosis}", body_text_style))

        doc.build(elements)

        # Save PDF to a file
        unique_filename = str(chief_concern_id) + "_Intake_Form.pdf"
        pdf_file_path = os.path.join("media/", unique_filename)
        # pdf_file_path = '/path/to/save/generated/pdf.pdf'  # Change this to your desired file path
        with open(pdf_file_path, 'wb') as f:
            f.write(buffer.getvalue())
        # Create Patient instance and save to the database
        intakeform = ChiefMedicalConcern(
            title=title,
            chief_concern_id = chief_concern_id,
            intake_form_file = pdf_file_path, 
            patient = patient
        )

        intakeform.save()
        
        messages.success(request, 'Intake Form and PDF generated created successfully')
        return redirect('view_patient', pk=pk)
    
    return render(request, 'powered_5_app/create-intake-form-final.html', {'p': profile_pk})

    # return render(request, 'powered_5_app/create-intake-form-final.html', {'p': profile_pk})
    # if the form exists and adds to the database given that patient pk, 
    # temporary make intake_form file fillable muna and not automatic
    # for the mean time, format of the files would be the title and stuff 
    # format of the pdf
    # puts now the data in the pdf w/o picture 
    # w/ picture changing only, with different circles already 

def add_sf36(request, pk):
    profile = get_object_or_404(Patient, pk=pk)
    if request.method == "POST":
        q1 = request.POST.get('q1')
        q2 = request.POST.get('q2')
        q3 = request.POST.get('q3')
        q4 = request.POST.get('q4')
        q5 = request.POST.get('q5')
        q6 = request.POST.get('q6')
        q7 = request.POST.get('q7')
        q8 = request.POST.get('q8')
        q9 = request.POST.get('q9')
        q10 = request.POST.get('q10')
        q11 = request.POST.get('q11')
        q12 = request.POST.get('q12')
        q13 = request.POST.get('q13')
        q14 = request.POST.get('q14')
        q15 = request.POST.get('q15')
        q16 = request.POST.get('q16')
        q17 = request.POST.get('q17')
        q18 = request.POST.get('q18')
        q19 = request.POST.get('q19')
        q20 = request.POST.get('q20')
        q21 = request.POST.get('q21')
        q22 = request.POST.get('q22')
        q23 = request.POST.get('q23')
        q24 = request.POST.get('q24')
        q25 = request.POST.get('q25')
        q26 = request.POST.get('q26')
        q27 = request.POST.get('q27')
        q28 = request.POST.get('q28')
        q29 = request.POST.get('q29')
        q30 = request.POST.get('q30')
        q31 = request.POST.get('q31')
        q32 = request.POST.get('q32')
        q33 = request.POST.get('q33')
        q34 = request.POST.get('q34')
        q35 = request.POST.get('q35')
        q36 = request.POST.get('q36')
        patient = Patient.objects.get(pk=pk)
        SF36.objects.create(patient=patient,q1=q1, q2=q2, q3=q3, q4=q4, q5=q5,
                            q6=q6, q7=q7, q8=q8, q9=q9, q10=q10, q11=q11, q12=q12,
                            q13=q13, q14=q14, q15=q15, q16=q16, q17=q17,q18=q18,
                            q19=q19, q20=q20, q21=q21, q22=q22, q23=q23, q24=q24,
                            q25=q25, q26=q26, q27=q27, q28=q28, q29=q29, q30=q30,
                            q31=q31, q32=q32, q33=q33, q34=q34, q35=q35, q36=q36)
        messages.success(request, 'SF36 added.')
        return redirect ('view_patient', pk=pk)
    else:
        return render (request, 'powered_5_app/add_sf36.html', {'p': profile})
    
def view_sf36(request, pk):
    sf36 = SF36.objects.get(pk=pk)
    if not sf36:
        messages.error(request, 'No SF36 added.')
    else:
        patient = sf36.patient
        physical_functioning = sf36.q3 + sf36.q4 + sf36.q5 + sf36.q6 + sf36.q7 + sf36.q8 + sf36.q9 + sf36.q10 + sf36.q11 + sf36.q12 / 10
        role_limitations_physical = sf36.q13 + sf36.q14 + sf36.q15 + sf36.q16 / 4
        role_limitations_emotional = sf36.q17 + sf36.q18 + sf36.q19 / 3
        energy_fatigue = sf36.q23 + sf36.q27 + sf36.q29 + sf36.q31 / 4
        emotional_wellbeing = sf36.q24 + sf36.q25 + sf36.q26 + sf36.q28 + sf36.q30 / 5
        social_functioning = sf36.q20 + sf36.q32 / 2
        pain = sf36.q21 + sf36.q22 / 2
        general_health = sf36.q1 + sf36.q33 + sf36.q34 + sf36.q35 + sf36.q36 / 5

        return render(request, 'powered_5_app/view_sf36.html', {
        'sf36': sf36,
        'patient': patient,
        'physical_functioning': physical_functioning,
        'role_limitations_physical': role_limitations_physical,
        'role_limitations_emotional': role_limitations_emotional,
        'energy_fatigue': energy_fatigue,
        'emotional_wellbeing': emotional_wellbeing,
        'social_functioning': social_functioning,
        'pain': pain,
        'general_health': general_health
        })
    
def delete_sf36(request, pk):
    sf36 = get_object_or_404(SF36, pk=pk)
    patient = sf36.patient.pk
    sf36.delete()
    return redirect('view_patient', pk=patient)

def transactions(request):
    transactionObjects = Session.objects.all()
    # return render(request, 'powered_5_app/transactions.html', {'Transactions':transactionObjects })
    return render(request, 'powered_5_app/transactions.html', {'transactions':transactionObjects })

#with no automatic save
# def display_image(request):
#     def on_image_click(event):
#         x = int(event.xdata)
#         y = int(event.ydata)
#         print(f"Clicked at coordinates: ({x}, {y})")
#         draw_circle(x, y, radius=20, color='orange')

#     def draw_circle(x, y, radius, color):
#         circle = plt.Circle((x, y), radius, color=color, fill=False)
#         ax.add_patch(circle)
#         plt.draw()

#     # Load the image
#     img = Image.open("powered_5_app/static/img/Pain_Chart.png")

#     # Display the image using matplotlib
#     fig, ax = plt.subplots()
#     ax.imshow(img)
#     ax.axis('off')  # Hide axes

#     # Bind the click event
#     fig.canvas.mpl_connect('button_press_event', on_image_click)

#     plt.show()

#     return render(request, 'powered_5_app/clickable_image.html')
# i like the most
# def display_image(request):
#     def on_image_click(event):
#         x = int(event.xdata)
#         y = int(event.ydata)
#         print(f"Clicked at coordinates: ({x}, {y})")
#         draw_circle(x, y, radius=20, color='orange')

#     def draw_circle(x, y, radius, color):
#         circle = plt.Circle((x, y), radius, color=color, fill=False)
#         ax.add_patch(circle)
#         plt.draw()

#     # Load the image
#     img_path = os.path.join("powered_5_app/static/img", "Pain_Chart.png")
#     img = Image.open(img_path)

#     # Display the image using matplotlib
#     fig, ax = plt.subplots()
#     ax.imshow(img)
#     ax.axis('off')  # Hide axes

#     # Bind the click event
#     fig.canvas.mpl_connect('button_press_event', on_image_click)

#     plt.show()

#     # Generate a random unique identifier
#     unique_filename = str(uuid.uuid4()) + "_Modified_Pain_Chart.png"
#     save_path = os.path.join("powered_5_app/static/img/Pain_Chart", unique_filename)

#     # Save the modified image
#     fig.savefig(save_path)

#     return render(request, 'powered_5_app/clickable_image.html')


# def display_image(request):
#     def on_image_click(event):
#         x = int(event.xdata)
#         y = int(event.ydata)
#         print(f"Clicked at coordinates: ({x}, {y})")
#         draw_circle(x, y, radius=20, color='orange')

#     def draw_circle(x, y, radius, color):
#         circle = plt.Circle((x, y), radius, color=color, fill=False)
#         ax.add_patch(circle)
#         plt.draw()

#     # Load the image
#     img_path = os.path.join("powered_5_app/static/img", "Pain_Chart.png")
#     img = Image.open(img_path)

#     # Display the image using matplotlib
#     fig, ax = plt.subplots()
#     ax.imshow(img)
#     ax.axis('off')  # Hide axes

#     # Bind the click event
#     fig.canvas.mpl_connect('button_press_event', on_image_click)

#     # Render the figure to a PNG image in memory
#     buf = io.BytesIO()
#     canvas = FigureCanvasAgg(fig)
#     canvas.print_png(buf)
#     plt.close(fig)

#     # Convert the PNG image to a base64 encoded string
#     image_base64 = buf.getvalue()

#     return render(request, 'powered_5_app/clickable_image.html', {'image_base64': image_base64})

# # experimentsuccessful
# def display_image(request):
#     def on_image_click(event):
#         x = int(event.xdata)
#         y = int(event.ydata)
#         print(f"Clicked at coordinates: ({x}, {y})")
#         draw_circle(x, y, radius=20, color='orange')

#     def draw_circle(x, y, radius, color):
#         circle = plt.Circle((x, y), radius, color=color, fill=False)
#         ax.add_patch(circle)
#         plt.draw()

#     # Load the image
#     img_path = os.path.join("powered_5_app/static/img", "Pain_Chart.png")
#     img = Image.open(img_path)

#     # Display the image using matplotlib
#     fig, ax = plt.subplots()
#     ax.imshow(img)
#     ax.axis('off')  # Hide axes

#     # Bind the click event
#     fig.canvas.mpl_connect('button_press_event', on_image_click)

#     plt.show()
#     modified_image_bytesio = io.BytesIO()
#     fig.savefig(modified_image_bytesio, format='png')
#     modified_image_bytesio.seek(0)  # Move the cursor to the start of the BytesIO object

#     encoded_image = base64.b64encode(modified_image_bytesio.getvalue()).decode("utf-8")

# #   Save the modified image
#     unique_filename = str(uuid.uuid4()) + "_Modified_Pain_Chart.png"
#     save_path = os.path.join("powered_5_app/static/img/Pain_Chart", unique_filename)

# #   Save the modified image
#     fig.savefig(save_path)

#     # return encoded_image
#     return render(request, 'powered_5_app/clickable_image.html',{'encoded_image': encoded_image})