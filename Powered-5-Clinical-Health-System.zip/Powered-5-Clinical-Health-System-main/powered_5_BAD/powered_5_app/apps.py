from django.apps import AppConfig


class Powered5AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'powered_5_app'
