"""
URL configuration for powered_5_BAD project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.user_login, name="login"),
    path('logout', views.user_logout, name="logout"),
    path('home', views.home, name="home"),
    path('calendar', views.calendar, name='calendar'),
    path('all_appointments', views.all_appointments, name='all_appointments'),
    path('all_therapist_schedules', views.all_therapist_schedules, name='all_therapist_schedules'),
    path('add_appointment', views.add_appointment, name='add_appointment'),
    path('edit_appointment/<str:pk>/', views.edit_appointment, name='edit_appointment'),
    path('delete_appointment/<str:pk>/', views.delete_appointment, name='delete_appointment'),
    path('add_therapist_schedule', views.add_therapist_schedule, name='add_therapist_schedule'),
    path('view_therapist_schedules', views.view_therapist_schedules, name='view_therapist_schedules'),
    path('edit_therapist_schedule/<int:pk>/', views.edit_therapist_schedule, name="edit_therapist_schedule"),
    path('delete_therapist_and_schedules/<int:pk>/', views.delete_therapist_and_schedules, name='delete_therapist_and_schedules'),
    path('patient_profiles', views.patientProfiles, name="patient_profiles"),
    path('add_patient', views.addProfile, name="add_patient"),
    path('view_patient/<int:pk>/', views.viewProfile, name="view_patient"),
    path('update_patient/<int:pk>/', views.updateProfile, name="update_patient"),
    path('delete_patient/<int:pk>/', views.deleteProfile, name="delete_patient"),
    path('createintakeform/<int:pk>/', views.createintakeform, name="createintakeform"),
    path('display-image/<int:pk>/', views.display_image, name='display_image'),
    path('add_sf36/<int:pk>/', views.add_sf36, name="add_sf36"),
    path('view_sf36/<int:pk>/', views.view_sf36, name="view_sf36"),
    path('delete_sf36/<int:pk>/', views.delete_sf36, name="delete_sf36"),
    path('transactions/',views.transactions, name="transactions")
    ]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)