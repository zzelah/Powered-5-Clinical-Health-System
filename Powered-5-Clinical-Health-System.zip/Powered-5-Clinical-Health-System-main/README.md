# Powered-5-Clinical-Health-System
Clinical Health System for Powered Recovery Wellness Hub, Aklan

Django project is setup and if you want to see the models use 8000/admin with
username: powered_5
password: coachpaul

On initial setup: 
1. Type in terminal: python -m venv whatevernameofvirtual environment
2. Activate and enter the virtual environment through typing in terminal: 
    a. MAC: source whatevernameofvirtual/bin/activate
    b. Windows: whatevernameofvirtual/bin/activate OR whatevernameofvirtual/Scripts/activate
3. Install dependencies through typing in terminal
    a. Check dependencies in virtual environment: pip list
    b. Install Django: pip install Django
    c. Install PyMySQL: pip install pymysql
    d. Install everything: pip install -r requirements.txt
4. Using terminal, navigate into the Django project of the repository:
    a. Type in terminal: cd powered_5_BAD
    b. Check if manage.py is there using either
        1. MAC: ls
        2. Windows: dir
5. Activate project typing: python manage.py runserver

Physical Therapist Login
powered_recovery_PT
coachpaul

NOTE:
Database management system is mysql. More specifically, mysql with XAMPP. Be suere to create a database called:
powered_5

As this the name of database that Django will read and use for the project.